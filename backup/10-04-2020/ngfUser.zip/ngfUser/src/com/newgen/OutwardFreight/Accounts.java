package com.newgen.OutwardFreight;

import com.newgen.Webservice.CallAccessTokenService;
import com.newgen.Webservice.CallPrePaymentService;
import com.newgen.Webservice.CallPurchaseOrderService;
import com.newgen.common.AccountsGeneral;
import com.newgen.common.Calculations;
import com.newgen.common.General;
import com.newgen.common.PicklistListenerHandler;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.component.ListView;
import com.newgen.omniforms.component.PickList;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

public class Accounts implements FormListener {

	FormReference formObject = null;
	FormConfig formConfig = null;
	String activityName = null, engineName = null, sessionId = null, folderId = null, serverUrl = null,
			processInstanceId = null, workItemId = null, userName = null, processDefId = null, Query = null;
	List<List<String>> result;
	PickList objPicklist;
	General objGeneral = null;
	Calculations objCalculations = null;
	PicklistListenerHandler objPicklistListenerHandler = null;
	AccountsGeneral objAccountsGeneral = null;

	@Override
	public void continueExecution(String aurg0, HashMap<String, String> arg1) {
		// TODO Auto-generated method stub
	}

	@Override
	public void eventDispatched(ComponentEvent pEvent) throws ValidatorException {
		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();
		objPicklistListenerHandler = new PicklistListenerHandler();
		objCalculations = new Calculations();
		objGeneral = new General();
		objAccountsGeneral = new AccountsGeneral();

		switch (pEvent.getType().name()) {
		case "VALUE_CHANGED":
			switch (pEvent.getSource().getName()) {
			}
		case "MOUSE_CLICKED":
			switch (pEvent.getSource().getName()) {
			}

		case "TAB_CLICKED":
			switch (pEvent.getSource().getName()) {
			}
		}
	}

	@Override
	public void formLoaded(FormEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println(" -------------------Intiation Workstep Loaded from formloaded.----------------");
		// TODO Auto-generated method stub
		System.out.println("form Loaded called : 20/05/2019");
		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();
		try {
			// objGeneral = new General();
			engineName = formConfig.getConfigElement("EngineName");
			sessionId = formConfig.getConfigElement("DMSSessionId");
			folderId = formConfig.getConfigElement("FolderId");
			serverUrl = formConfig.getConfigElement("ServletPath");
			activityName = formObject.getWFActivityName();
			processInstanceId = formConfig.getConfigElement("ProcessInstanceId");
			workItemId = formConfig.getConfigElement("WorkitemId");
			userName = formConfig.getConfigElement("UserName");
			processDefId = formConfig.getConfigElement("ProcessDefId");

			System.out.println("ProcessInstanceId===== " + processInstanceId);
			System.out.println("Activityname=====" + activityName);
			System.out.println("CabinetName====" + engineName);
			System.out.println("sessionId====" + sessionId);
			System.out.println("Username====" + userName);
			System.out.println("workItemId====" + workItemId);

//  ************************************************************************************
		} catch (Exception e) {
			System.out.println("Exception in FieldValueBagSet::::" + e.getMessage());
		}
	}

	@Override
	public void formPopulated(FormEvent arg0) {
		System.out.println("inside form populate ofaccounts service po");
		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();
		System.out.println(
				"----------------------I ntiation Workstep Loaded from form populated........---------------------------");
		objGeneral = new General();
		// objGeneral.setTaxDocumentHeader("TaxDocument");
		formObject.setNGValue("filestatus", "");
		formObject.clear("filestatus");
		formObject.addComboItem("filestatus", "Approved", "Approved");
		formObject.addComboItem("filestatus", "Query Raised", "Query Raised");
		System.out.println("filestatus value" + formObject.getNGValue("filestatus"));

			formObject.setEnabled("Pick_journalname", true);
			formObject.setVisible("Pick_journalname", true);
			formObject.setEnabled("journalcode", true);
			formObject.setVisible("journalcode", true);
		
			 Query = "select calculatewithholdingtax,TDSGroup from VendorMaster where VendorCode	= '"+ formObject.getNGValue("accountcode")+"'";
				result = formObject.getDataFromDataSource(Query);
				if(result.size() > 0) {
					if(result.get(0).get(0).equalsIgnoreCase("0")) {
						formObject.setSheetVisible("Tab1", 5, false);
					}
					else {
						formObject.setSheetVisible("Tab1", 5, true);
					}
				}
//        try {
//            Query = "select StateCode from StateMaster order by StateCode asc";
//            System.out.println("Query is " + Query);
//            result = formObject.getDataFromDataSource(Query);
//            System.out.println("resut is " + result);
//            for (int i = 0; i < result.size(); i++) {
//                formObject.addComboItem("state", result.get(i).get(0), result.get(i).get(0));
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
	}

	@Override
	public void saveFormCompleted(FormEvent arg0) throws ValidatorException {
		// TODO Auto-generated method stub
		System.out.print("-------------------save form completed---------");
	}

	@Override
	public void saveFormStarted(FormEvent arg0) throws ValidatorException {
		// TODO Auto-generated method stub
		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();

	}

	@Override
	public void submitFormCompleted(FormEvent arg0) throws ValidatorException {
		// TODO Auto-generated method stub
		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();

	}

	@Override
	public void submitFormStarted(FormEvent arg0) throws ValidatorException {
		// TODO Auto-generated method stub
		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();
		System.out.println("**********-------SUBMIT FORM Started------------*************");
		String proctype = formObject.getNGValue("proctype").replace(",", "%");
		try {
			if (formObject.getNGValue("filestatus").equalsIgnoreCase("Query Raised")) {
				System.out.println("inside activity accounts");
				Query = "select TOP 1 ApproverCode from FreightBillApproverMaster where state = '" + formObject.getNGValue("state") + "' order by ApproverLevel DESC";
				System.out.println("Query1:" + Query);
				result = formObject.getDataFromDataSource(Query);
				System.out.println("result is" + result);
				if (result.size() > 0) {
					formObject.setNGValue("assignto", result.get(0).get(0));
				} else {
					formObject.setNGValue("assignto", "NA");
				}
			} else if (formObject.getNGValue("filestatus").equalsIgnoreCase("Approved")) {
				String levelflag = formObject.getNGValue("levelflag");
				if (levelflag.equalsIgnoreCase("Maker")) {
					Query = "select ApproverLevel, ApproverCode from FreightBillApproverMaster where state = '"
							+ formObject.getNGValue("state") + "' " + "and ApproverLevel ='Checker'";
					System.out.println("Query " + Query);
					result = formObject.getDataFromDataSource(Query);
					if (result.size() > 0) {
						formObject.setNGValue("assignto", result.get(0).get(1));
						formObject.setNGValue("nextactivity", "Accounts");
						formObject.setNGValue("levelflag", "Checker");
					} else {
						formObject.setNGValue("nextactivity", "SchedularAccount");
					}
				} else {
					formObject.setNGValue("nextactivity", "SchedularAccount");
				}
			}
			System.out.println("value in assign to" + formObject.getNGValue("assignto"));

//                formObject.setNGValue("nextactivity", formObject.getNGValue("previousactivity"));
			formObject.setNGValue("previousactivity", activityName);
			objGeneral.maintainHistory(userName, activityName, formObject.getNGValue("filestatus"), "",
					formObject.getNGValue("Text15"), "q_transactionhistory");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void initialize() {
		throw new UnsupportedOperationException("Not supported yet.");
	}

	public String encrypt(String string) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	public String decrypt(String string) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	void setPOLineNumber(String linenumberId) {
		formObject.clear(linenumberId);
		Query = "select linenumber from cmplx_invoicedetails where pinstanceid = '" + processInstanceId + "'";
		System.out.println("Query :" + Query);
		result = formObject.getDataFromDataSource(Query);
		if (result.size() > 0) {
			for (List<String> result1 : result) {
				formObject.addComboItem(linenumberId, result1.get(0), result1.get(0));
			}
		}
	}

	void setPOItemNumber(String itemnumberId, String linenumberId, String assessableamountId) {
		Query = "select itemid,assessableamount from cmplx_invoicedetails where pinstanceid = '" + processInstanceId
				+ "' " + "and linenumber = '" + formObject.getNGValue(linenumberId) + "'";
		System.out.println("Query :" + Query);
		result = formObject.getDataFromDataSource(Query);
		formObject.setNGValue(itemnumberId, result.get(0).get(0));

		if (!assessableamountId.equalsIgnoreCase("")) {
			formObject.setNGValue(assessableamountId, result.get(0).get(1));
		}
	}

	void addAssessableAmount(String operator, String linenumber, String itemnumber, BigDecimal assessableamount) {

		String addedAssessable = "";
		ListView ListViewq_invoicedetails = (ListView) formObject.getComponent("q_invoicedetails");
		int rowCount = ListViewq_invoicedetails.getRowCount();
		System.out.println("Row count : " + rowCount);
		if (rowCount > 0) {
			for (int i = 0; i < rowCount; i++) {
				if (formObject.getNGValue("q_invoicedetails", i, 0).equalsIgnoreCase(linenumber)
						&& formObject.getNGValue("q_invoicedetails", i, 1).equalsIgnoreCase(itemnumber)) {
					if (operator.equalsIgnoreCase("Add")) {
						addedAssessable = new BigDecimal(formObject.getNGValue("q_invoicedetails", i, 10))
								.add(assessableamount).toString();
					} else {
						addedAssessable = new BigDecimal(formObject.getNGValue("q_invoicedetails", i, 10))
								.subtract(assessableamount).toString();
					}
					formObject.setNGValue("q_invoicedetails", i, 10, addedAssessable);
					break;
				}
			}

		}
	}
}
