package com.newgen.OutwardFreight;

import com.newgen.Webservice.CallGetFreightDetail;
import com.newgen.common.Calculations;
import com.newgen.common.General;
import com.newgen.common.PicklistListenerHandler;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.component.PickList;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import java.util.HashMap;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

public class Initiator implements FormListener {
	
	FormReference formObject = null;
	FormConfig formConfig = null;
	String activityName = null, engineName = null, sessionId = null, folderId = null, serverUrl = null,
			processInstanceId = null, workItemId = null, userName = null, processDefId = null, Query = null;
	List<List<String>> result;
	PickList objPicklist = null;
	General objGeneral = null;
	Calculations objCalculations = null;
	PicklistListenerHandler objPicklistListenerHandler = null;
	CallGetFreightDetail objGetSetFreightDetail = null;

	@Override
	public void continueExecution(String arg0, HashMap<String, String> arg1) {

	}

	@Override
	public void eventDispatched(ComponentEvent pEvent) throws ValidatorException {
		System.out.println("Value Change Event :" + pEvent);
		System.out.println("pEvent.getType() :" + pEvent.getType());
		System.out.println("pEvent.getType().name() :" + pEvent.getType().name());
		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();
		objPicklistListenerHandler = new PicklistListenerHandler();
		objGetSetFreightDetail = new CallGetFreightDetail();
		objCalculations = new Calculations();
		objGeneral = new General();
		switch (pEvent.getType().name()) {
		case "VALUE_CHANGED":

			switch (pEvent.getSource().getName()) {
			case "baseamount":
			case "account":
				System.out.println("Account Code value : "+formObject.getNGValue("accountcode"));
				
				Query = "select Address, GSTINNumber, StateName,AddressId,AddressName from AddressMaster where PartyCode = '"
						+ formObject.getNGValue("accountcode") + "'";
				System.out.println("Query value: "+Query);
				result = formObject.getDataFromDataSource(Query);
				System.out.println("result value: "+result.get(0).get(0)+","+result.get(0).get(1));
				if(result.size() > 0) {
								
					formObject.setNGValue("vendoraddress", result.get(0).get(0));
					formObject.setNGValue("vendorgstingdiuid", result.get(0).get(1));
					formObject.setNGValue("vendorstate", result.get(0).get(2));
					formObject.setNGValue("vendorlocation", result.get(0).get(3));
					formObject.setNGValue("vendortaxinformation", result.get(0).get(4));
					
				}		
				break;
			case "currency":
				objCalculations.exronCurrencyChange("currency", "invoiceamount", "newbaseamount",
						"exchangerateotherthaninr");
				break;
			case "exchangerateotherthaninr":
				objCalculations.exronBaseamountandExchangerateChange("currency", "baseamount", "newbaseamount",
						"exchangerateotherthaninr");
				break;

			case "order_type":
				System.out.println("inside value change of order_type");
				if (formObject.getNGValue("order_type").equalsIgnoreCase("SalesOrder")) {
					formObject.setEnabled("q_AdjustedShortageValue", true);
				}
				break;
			
			case "CheckBox1":
				System.out.println("inside value change of CheckBox1");
				if (formObject.getNGValue("CheckBox1").equalsIgnoreCase("true")) {
					formObject.setNGValue("qwht_tdsgroup","");
					formObject.setNGValue("qwht_tdspercent","");
					formObject.setNGValue("qwht_adjustedoriginamount","");
					formObject.setNGValue("qwht_tdsamount","");
					formObject.setNGValue("qwht_adjustedtdsamount","");
				}
				break;
			}
			break;

		case "MOUSE_CLICKED":
			switch (pEvent.getSource().getName()) {
			case "Button2":                      // fetch button
				System.out.println("Inside fetch button called for web service");
				try {
					System.out.println("Invoice Number: " + formObject.getNGValue("invoicenumber"));
					System.out.println("Account Code: "+formObject.getNGValue("accountcode"));
					objGetSetFreightDetail.GetSetFreightDetail("NewGen", formObject.getNGValue("accountcode"),
							formObject.getNGValue("invoicenumber"));
					
					Query = "select calculatewithholdingtax,TDSGroup from VendorMaster where VendorCode	= '"+ formObject.getNGValue("accountcode")+"'";
					System.out.println("Query account pick tds group: " + Query);
					result = formObject.getDataFromDataSource(Query);
					System.out.println("result account pick tds group: "+result.get(0).get(0)+","+result.get(0).get(1));
					if(result.size() > 0) {
						if(result.get(0).get(0).equalsIgnoreCase("0")) {
							System.out.println("Inside sheet disable");
							formObject.setSheetVisible("Tab1", 5, false);
						}else {
//						formObject.setNGValue("qwht_tdsgroup", result.get(0).get(1));
						System.out.println("Inside tdsdatainitialize account");
						tdsdatainitialize(result.get(0).get(1),formObject.getNGValue("TotalFreight"));
						}}
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;

			case "Pick_account":
				Query = "select VendorCode,VendorName from VendorMaster order by VendorCode asc";
				objPicklistListenerHandler.openPickList("account", "Code,Name", "Vendor Master", 70, 70, Query);
				break;

			case "Pick_paymentterm":
				Query = "select PaymentTermCode,PaymentTermDesc from PaymentTermMaster";
				objPicklistListenerHandler.openPickList("paymentterm", "Code,Description", "Payment Term Master", 70,
						70, Query);
				break;

			case "Pick_tdsgroup":
				Query = "select Code,Description from TDSMaster order by Code asc";
				objPicklistListenerHandler.openPickList("qwht_tdsgroup", "Code,Description", "TDS Group Master", 70, 70,
						Query);
				break;
				
			case "Pick_hsnsac":
				String hsnsaccodetype = formObject.getNGValue("qtd_hsnsactype");
				System.out.println("hsnsaccodetype inside pick_hsansac: "+formObject.getNGValue("qtd_hsnsactype"));
                if (hsnsaccodetype.equalsIgnoreCase("HSN")) {
                    Query = "select HSNCode,Description from HSNMaster order by HSNCode asc";
                    objPicklistListenerHandler.openPickList("qtd_hsnsacdescription", "Code,Description", "HSN Master", 70, 70, Query);
                } else if (hsnsaccodetype.equalsIgnoreCase("SAC")) {
                    Query = "select SACCode,Description from SACMaster order by SACCode asc";
                    objPicklistListenerHandler.openPickList("qtd_hsnsacdescription", "Code,Description", "SAC Master", 70, 70, Query);
                } else {
                    throw new ValidatorException(new FacesMessage("Kindly select the type value"));
                }
                break;
                
			case "Pick_journalname":
				Query = "select Code,Description from JournalNamemaster order by Code asc";
				objPicklistListenerHandler.openPickList("journalname", "Code,Description", "TDS Group Master", 70, 70,Query);
				break;
			}
			break;
		}
	}
	
	@Override
	public void formLoaded(FormEvent arg0) {
		System.out.println(" -------------------Intiation Workstep Loaded from formloaded.----------------");
		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();
		try {
			engineName = formConfig.getConfigElement("EngineName");
			sessionId = formConfig.getConfigElement("DMSSessionId");
			folderId = formConfig.getConfigElement("FolderId");
			serverUrl = formConfig.getConfigElement("ServletPath");
			activityName = formObject.getWFActivityName();
			processInstanceId = formConfig.getConfigElement("ProcessInstanceId");
			workItemId = formConfig.getConfigElement("WorkitemId");
			userName = formConfig.getConfigElement("UserName");
			processDefId = formConfig.getConfigElement("ProcessDefId");

			System.out.println("ProcessInstanceId===== " + processInstanceId);
			System.out.println("Activityname=====" + activityName);
			System.out.println("CabinetName====" + engineName);
			System.out.println("sessionId====" + sessionId);
			System.out.println("Username====" + userName);
			System.out.println("workItemId====" + workItemId);
		} catch (Exception e) {
			System.out.println("Exception in FieldValueBagSet::::" + e.getMessage());
		}
	}

	@Override
	public void formPopulated(FormEvent arg0) {
		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();

		formObject.setNGValue("accounttype", "Vendor");
		formObject.setNGValue("amounttype", "Credit");

		formObject.clear("filestatus");

		if (!formObject.getNGValue("previousactivity").equalsIgnoreCase("Approver")
				&& !formObject.getNGValue("previousactivity").equalsIgnoreCase("Accounts")) {
			formObject.addComboItem("filestatus", "Initiate", "Initiate");
			formObject.addComboItem("filestatus", "Discard", "Discard");
		} else {

			formObject.addComboItem("filestatus", "Hold", "Hold");
			formObject.addComboItem("filestatus", "Query Cleared", "Query Cleared");
			formObject.addComboItem("filestatus", "Discard", "Discard");
			
		}
	}

	@Override
	public void saveFormCompleted(FormEvent arg0) throws ValidatorException {

		System.out.print("-------------------save form completed---------");
	}

	@Override
	public void saveFormStarted(FormEvent arg0) throws ValidatorException {

		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();

	}

	@Override
	public void submitFormCompleted(FormEvent arg0) throws ValidatorException {

		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();

	}

	@Override
	public void submitFormStarted(FormEvent arg0) throws ValidatorException {
		formObject = FormContext.getCurrentInstance().getFormReference();
		formConfig = FormContext.getCurrentInstance().getFormConfig();
		objCalculations = new Calculations();
		objGeneral = new General();
		System.out.println("**********-------SUBMIT FORM Started Non PO Invoice------------*************");

		int levelflag = Integer.parseInt(formObject.getNGValue("levelflag")) + 1;
		Query = "select ApproverCode from FreightBillApproverMaster where " + "and ApproverLevel='" + levelflag + "' "
				+ "and State ='" + formObject.getNGValue("state") + "'";
		System.out.println("Query:" + Query);
		result = formObject.getDataFromDataSource(Query);
		System.out.println("result" + result);
		if (result.size() > 0) {
			formObject.setNGValue("nextactivity", "Approver");
			formObject.setNGValue("assignto", result.get(0).get(0));
			formObject.setNGValue("levelflag", levelflag);
		} else {

			Query = "select ApproverLevel, ApproverCode from FreightBillApproverMaster where  " + "and state = '"
					+ formObject.getNGValue("state") + "' " + "and approverlevel in ('Maker', 'Checker')";
			System.out.println("query  for level is " + Query);
			result = formObject.getDataFromDataSource(Query);
			if (result.size() > 0) {
				if (result.get(0).get(0).equalsIgnoreCase("Maker")) {
					formObject.setNGValue("levelflag", "Maker");
				} else if (result.get(0).get(0).equalsIgnoreCase("Checker")) {
					formObject.setNGValue("levelflag", "Checker");
				}
				formObject.setNGValue("assignto", result.get(0).get(1));
				formObject.setNGValue("nextactivity", "Accounts");
			} else {
				formObject.setNGValue("nextactivity", "SchedularAccount");
				// formObject.setNGValue("assignto", "NA");
			}

		}
		formObject.setNGValue("previousactivity", activityName);
		objGeneral.maintainHistory(userName, activityName, formObject.getNGValue("filestatus"), "",
				formObject.getNGValue("Text51"), "q_transactionhistory");
	}

	@Override
	public void initialize() {
		throw new UnsupportedOperationException("Not supported yet.");
	}
	
	public void tdsdatainitialize(String tdsgroup, String adjustedamountorigin) {
		System.out.println("Inside tdsdatainitialize method");
		 String calculatedValue = ""; 
//		String adjustedamountorigin = formObject.getNGValue("qwht_adjustedoriginamount");
//		adjustedamountorigin = formObject.getNGValue("TotalFreight");
         Query = "select TaxPercwithPAN from TDSMaster where code = '"+tdsgroup+"'";
         System.out.println("TDS Query : " + Query);
         result = formObject.getDataFromDataSource(Query);
         System.out.println("TDS result : " + result.get(0).get(0));
         if (result.size() > 0) {
//             formObject.setNGValue("qwht_tdspercent", result.get(0).get(0));
             calculatedValue = objCalculations.calculatePercentAmount(adjustedamountorigin, result.get(0).get(0));
//             formObject.setNGValue("qwht_tdsamount", calculatedValue);
//             formObject.setNGValue("qwht_adjustedtdsamount", calculatedValue);
         }
         String withholdingXML = "<ListItem>"
					+ "<SubItem>" + tdsgroup + "</SubItem>"
					+ "<SubItem>" + result.get(0).get(0) + "</SubItem>"
					+ "<SubItem>" + adjustedamountorigin + "</SubItem>"
					+ "<SubItem>" + calculatedValue + "</SubItem>"
					+ "<SubItem>" + calculatedValue	+ "</SubItem>"
					+ "</ListItem>";
         System.out.println("withholdingtaxXMl: "+withholdingXML);
         formObject.NGAddListItem("q_withholding_tax", withholdingXML);
	}

	public String encrypt(String string) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}

	public String decrypt(String string) {
		throw new UnsupportedOperationException("Not supported yet."); // To change body of generated methods, choose
																		// Tools | Templates.
	}
}
