/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.SupplyPoInvoices;

import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.component.IRepeater;
import com.newgen.omniforms.context.FormContext;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Admin
 */
public class SupplyPoRepeaterHeader {

    FormReference formObject = null;

    public void repeaterHeader() {
        formObject = FormContext.getCurrentInstance().getFormReference();

        IRepeater QCNorms = formObject.getRepeaterControl("QCNorms");
        List<String> QCNorms_HeaderNames = new ArrayList<>();
        QCNorms_HeaderNames.add(0, "Item Number");
        QCNorms_HeaderNames.add(1, "Test Group");
        QCNorms_HeaderNames.add(2, "Test");
        QCNorms_HeaderNames.add(3, "Min.");
        QCNorms_HeaderNames.add(4, "Max.");
        QCNorms_HeaderNames.add(5, "Penalty/Bonus");
        QCNorms_HeaderNames.add(6, "Total Amount");
        QCNorms.setRepeaterHeaders(QCNorms_HeaderNames);

        IRepeater OtherCharges = formObject.getRepeaterControl("OtherCharges");
        List<String> OtherCharges_HeaderNames = new ArrayList<>();
        OtherCharges_HeaderNames.add(0, "Line Number");
        OtherCharges_HeaderNames.add(1, "Charge Type");
        OtherCharges_HeaderNames.add(2, "Charges Code");
        OtherCharges_HeaderNames.add(3, "Category");
        OtherCharges_HeaderNames.add(4, "Assessable Value");
        OtherCharges_HeaderNames.add(5, "Charges Value");
        OtherCharges_HeaderNames.add(6, "Calculated Amount");
        OtherCharges_HeaderNames.add(7, "Vendor Account");
        OtherCharges.setRepeaterHeaders(OtherCharges_HeaderNames);

        IRepeater Retention = formObject.getRepeaterControl("Retention");
        List<String> Retention_HeaderNames = new ArrayList<>();
        Retention_HeaderNames.add(0, "Credit");
        Retention_HeaderNames.add(1, "Retention%");
        Retention_HeaderNames.add(2, "Retention Amount");
        Retention_HeaderNames.add(3, "Total Retention Amount");
        Retention.setRepeaterHeaders(Retention_HeaderNames);

        IRepeater TaxDocument = formObject.getRepeaterControl("TaxDocument");
        List<String> TaxDocument_HeaderNames = new ArrayList<>();
        TaxDocument_HeaderNames.add(0, "Tax Component");
        TaxDocument_HeaderNames.add(1, "Rate");
        TaxDocument_HeaderNames.add(2, "Tax Amount");
        TaxDocument_HeaderNames.add(3, "Tax Amount Adjustment");
        TaxDocument_HeaderNames.add(4, "Non-Business Usage Amount");
        TaxDocument_HeaderNames.add(5, "Reverse Charge Amount");
        TaxDocument_HeaderNames.add(6, "Reverse Charge%");
        TaxDocument_HeaderNames.add(7, "CST/VAT%");
        TaxDocument_HeaderNames.add(7, "CST/VATAmount");
        TaxDocument.setRepeaterHeaders(TaxDocument_HeaderNames);
        
        IRepeater PrePayment = formObject.getRepeaterControl("PrePayment");
        List<String> PrePayment_HeaderNames = new ArrayList<>();
        PrePayment_HeaderNames.add(0, "Pre Payment Invoice Number");
        PrePayment_HeaderNames.add(1, "Pre Payment Invoice Amount");
        PrePayment_HeaderNames.add(2, "Partial Payment Amount");
        PrePayment_HeaderNames.add(3, "Remaining Amount");
        PrePayment.setRepeaterHeaders(PrePayment_HeaderNames);
    }
}
