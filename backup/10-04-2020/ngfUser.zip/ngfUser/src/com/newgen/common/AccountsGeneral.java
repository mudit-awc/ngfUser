/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.common;

import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.component.ListView;
import com.newgen.omniforms.context.FormContext;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AccountsGeneral implements Serializable {

    FormReference formObject = null;
    List<List<String>> result, resultTaxDocument;
    Calculations objCalculations = null;
    private String Query;

    public void setRetention(String Query, String PaymentTermId, String RetCreditFieldId, String RetPercentFieldId, String RetAmountFieldId) {
        formObject = FormContext.getCurrentInstance().getFormReference();
        objCalculations = new Calculations();
        result = formObject.getDataFromDataSource(Query);
        System.out.println("result : " + result);
        ArrayList<String> baseamount = new ArrayList<String>();
        for (int i = 0; i < result.size(); i++) {
            baseamount.add(result.get(i).get(0));
        }
        formObject.setNGValue(RetCreditFieldId, objCalculations.calculateSum(baseamount));
        System.out.println("before second Query");
        Query = "select retentionpercent from PaymentTermMaster "
                + "where PaymentTermCode = '" + formObject.getNGValue(PaymentTermId) + "' "
                + "and retentionpercent is not null";
        System.out.println("Query2 : " + Query);
        result = formObject.getDataFromDataSource(Query);
        System.out.println("result 2 : " + result.size());
        if (result.size() > 0) {
            System.out.println("inside if");
            formObject.setNGValue(RetPercentFieldId, result.get(0).get(0));
            formObject.setEnabled(RetAmountFieldId, false);
            System.out.println("RetPercentFieldId in if " + formObject.getNGValue(RetPercentFieldId));
        } else {
            System.out.println("inside else ");
            formObject.setNGValue(RetPercentFieldId, "0");
            formObject.setEnabled(RetAmountFieldId, true);
            System.out.println("RetPercentFieldId " + formObject.getNGValue(RetPercentFieldId));
        }
    }

    public void setWithHoldingTax(String Query, String WithHoldingLvId) {
        formObject = FormContext.getCurrentInstance().getFormReference();
        objCalculations = new Calculations();
        ListView ListViewq_withholdingtax = (ListView) formObject.getComponent(WithHoldingLvId);
        int rowCount = ListViewq_withholdingtax.getRowCount();
        if (rowCount == 0) {
            System.out.println("Query withholding tax: " + Query);
            result = formObject.getDataFromDataSource(Query);
            System.out.println("Result size: " + result.size());
            if (result.size() > 0) {
                System.out.println("Result size>0");
                String WithholdingLineXML = "";
                for (int i = 0; i < result.size(); i++) {
                    String calculatedtaxamount = objCalculations.calculatePercentAmount(
                            result.get(0).get(4),
                            result.get(0).get(3)
                    );
                    WithholdingLineXML = (new StringBuilder()).append(WithholdingLineXML).
                            append("<ListItem><SubItem>").append(result.get(i).get(0)).
                            append("</SubItem><SubItem>").append(result.get(i).get(1)).
                            append("</SubItem><SubItem>").append(result.get(i).get(2)).
                            append("</SubItem><SubItem>").append(result.get(i).get(3)).
                            append("</SubItem><SubItem>").append(result.get(i).get(4)).
                            append("</SubItem><SubItem>").append(calculatedtaxamount).
                            append("</SubItem><SubItem>").append(calculatedtaxamount).
                            append("</SubItem></ListItem>").toString();
                }
                System.out.println("Withholding Line XML " + WithholdingLineXML);
                formObject.NGAddListItem(WithHoldingLvId, WithholdingLineXML);
            }
        }
    }

    public void setTaxDocument(String Query, String TaxDocumentLvId, String processInstaceId) {
        //Tax Document
        System.out.println("Inside setTaxDocument");

        formObject = FormContext.getCurrentInstance().getFormReference();
        objCalculations = new Calculations();
//        ListView ListViewq_taxdocument = (ListView) formObject.getComponent(TaxDocumentLvId);
//        int rowCount = ListViewq_taxdocument.getRowCount();
//        if (rowCount == 0) {
        try {
            System.out.println("Query :" + Query);
            resultTaxDocument = formObject.getDataFromDataSource(Query);
            if (resultTaxDocument.size() > 0) {
                String TaxDocumentXML = "";
                for (int i = 0; i < resultTaxDocument.size(); i++) {
                    String countQuery = "select count(*) from cmplx_taxdocument "
                            + "where linenumber = '" + resultTaxDocument.get(i).get(0) + "' "
                            + "and itemnumber = '" + resultTaxDocument.get(i).get(1) + "' "
                            + "and pinstanceid = '" + processInstaceId + "'";
                    System.out.println("Count Query : " + countQuery);
                    List<List<String>> countResult = formObject.getDataFromDataSource(countQuery);
                    if (countResult.get(0).get(0).equalsIgnoreCase("0")) {
                        //HSN or SAC
                        String hsnsactype = "", hsnsacdescription = "", hsnsaccode = "";
                        if ("NULL".equalsIgnoreCase(resultTaxDocument.get(i).get(3))
                                || null == resultTaxDocument.get(i).get(3)
                                || "".equalsIgnoreCase(resultTaxDocument.get(i).get(3))) {
                            hsnsactype = "SAC";
                            hsnsaccode = resultTaxDocument.get(i).get(4);
                            Query = "select Description from SACMaster where SACCode = '" + hsnsaccode + "'";
                        } else {
                            hsnsactype = "HSN";
                            hsnsaccode = resultTaxDocument.get(i).get(3);
                            Query = "select Description from HSNMaster where HSNCode = '" + hsnsaccode + "'";
                        }
                        System.out.println("HSNSAC Type :" + hsnsactype);
                        System.out.println("Query :" + Query);
                        List<List<String>> result_hsnsac = formObject.getDataFromDataSource(Query);
                        if (result_hsnsac.size() > 0) {
                            hsnsacdescription = result_hsnsac.get(0).get(0);
                        }

                        //Tax component
                        String taxcomponent = null, taxrate = null, taxamount = null, reversechargerate = null, reversechargeamount = null;
                        if ("No".equalsIgnoreCase(resultTaxDocument.get(i).get(14))) {
                            if ("0.0".equalsIgnoreCase(resultTaxDocument.get(i).get(5))
                                    && "0.0".equalsIgnoreCase(resultTaxDocument.get(i).get(6))) {
                                for (int j = 0; j < 2; j++) {
                                    System.out.println("Tax Compoonent Loop: " + j);
                                    if (j == 0) {
                                        taxcomponent = "SGST";
                                        taxrate = resultTaxDocument.get(i).get(9);
                                    } else {
                                        taxcomponent = "CGST";
                                        taxrate = resultTaxDocument.get(i).get(7);
                                    }
                                    taxamount = objCalculations.calculatePercentAmount(resultTaxDocument.get(i).get(13), taxrate);
                                    reversechargerate = getReverseChargeRate(hsnsactype, hsnsaccode, taxcomponent, "Vendor", formObject.getNGValue("suppliercode"));
                                    System.out.println("Reverse charge rate" + reversechargerate);
                                    reversechargeamount = objCalculations.calculatePercentAmount(resultTaxDocument.get(i).get(13), reversechargerate);
                                    System.out.println("Reverse Charge Amount :" + reversechargeamount);
                                    TaxDocumentXML = getTaxDocumentXml(
                                            TaxDocumentXML,
                                            resultTaxDocument.get(i).get(0), //line number
                                            resultTaxDocument.get(i).get(1), //item number
                                            resultTaxDocument.get(i).get(2), //gstingdiuid
                                            hsnsactype, //hsnsac type
                                            hsnsaccode, //hsnsac code
                                            hsnsacdescription, //hsnsac description
                                            taxcomponent, //tax component
                                            taxrate, //rate
                                            taxamount,//tax amount
                                            taxamount, //adjustment tax amount
                                            resultTaxDocument.get(i).get(11), //non business usage %
                                            reversechargerate, //reverse charge %
                                            reversechargeamount, //reverse charge amount
                                            resultTaxDocument.get(i).get(14), //Non-Gst
                                            resultTaxDocument.get(i).get(12)); //exempt
                                }
                            } else {
                                taxcomponent = "IGST";
                                taxrate = resultTaxDocument.get(i).get(5);
                                taxamount = objCalculations.calculatePercentAmount(resultTaxDocument.get(i).get(13), taxrate);
                                reversechargerate = getReverseChargeRate(hsnsactype, hsnsaccode, taxcomponent, "Vendor", formObject.getNGValue("suppliercode"));
                                System.out.println("Reverse charge rate" + reversechargerate);
                                reversechargeamount = objCalculations.calculatePercentAmount(resultTaxDocument.get(i).get(13), reversechargerate);
                                System.out.println("Reverse Charge Amount :" + reversechargeamount);
                                TaxDocumentXML = getTaxDocumentXml(
                                        TaxDocumentXML,
                                        resultTaxDocument.get(i).get(0), //line number
                                        resultTaxDocument.get(i).get(1), //item number
                                        resultTaxDocument.get(i).get(2), //gstingdiuid
                                        hsnsactype, //hsnsac type
                                        hsnsaccode, //hsnsac code
                                        hsnsacdescription, //hsnsac description
                                        taxcomponent, //tax component
                                        taxrate, //rate
                                        taxamount,//tax amount
                                        taxamount, //adjustment tax amount
                                        resultTaxDocument.get(i).get(11), //non business usage %
                                        reversechargerate, //reverse charge %
                                        reversechargeamount, //reverse charge amount
                                        resultTaxDocument.get(i).get(14), //Non-Gst
                                        resultTaxDocument.get(i).get(12)); //exempt
                            }
                        } else {
                            taxcomponent = resultTaxDocument.get(i).get(15);
                            taxrate = resultTaxDocument.get(i).get(16);
                            taxamount = objCalculations.calculatePercentAmount(resultTaxDocument.get(i).get(13), taxrate);
                            reversechargerate = "0";
                            reversechargeamount = "0";
                            TaxDocumentXML = getTaxDocumentXml(
                                    TaxDocumentXML,
                                    resultTaxDocument.get(i).get(0), //line number
                                    resultTaxDocument.get(i).get(1), //item number
                                    resultTaxDocument.get(i).get(2), //gstingdiuid
                                    hsnsactype, //hsnsac type
                                    hsnsaccode, //hsnsac code
                                    hsnsacdescription, //hsnsac description
                                    taxcomponent, //tax component
                                    taxrate, //rate
                                    taxamount,//tax amount
                                    taxamount, //adjustment tax amount
                                    resultTaxDocument.get(i).get(11), //non business usage %
                                    reversechargerate, //reverse charge %
                                    reversechargeamount, //reverse charge amount
                                    resultTaxDocument.get(i).get(14), //Non-Gst
                                    resultTaxDocument.get(i).get(12)); //exempt
                        }
                    }
                }
                System.out.println("Tax Document XML " + TaxDocumentXML);
                formObject.NGAddListItem(TaxDocumentLvId, TaxDocumentXML);

            }
        } catch (Exception e) {
            System.out.println("Exception :" + e.getMessage());
            e.printStackTrace();
        }
        //}
    }

    public String getReverseChargeRate(String hsnsaccodetype, String hsnsaccodevalue, String TaxComponenet, String accountype, String accountcode) {
        formObject = FormContext.getCurrentInstance().getFormReference();
        String ReverseChargeRate = "0", SelectColumn = "";
        if (TaxComponenet.equalsIgnoreCase("CGST")) {
            System.out.println("CGST");
            SelectColumn = "CGSTRCMPerc";
        } else if (TaxComponenet.equalsIgnoreCase("SGST")) {
            System.out.println("SGST");
            SelectColumn = "SGSTRCMPerc";
        } else if (TaxComponenet.equalsIgnoreCase("IGST")) {
            System.out.println("IGST");
            SelectColumn = "IGSTRCMPerc";
        }
        if (hsnsaccodetype.equalsIgnoreCase("HSN")) {
            System.out.println("HSN");
            Query = "Select " + SelectColumn + " from HSNRateMaster where HSNCode = '" + hsnsaccodevalue + "'";
            System.out.println("Query HSN: " + Query);
        } else if (hsnsaccodetype.equalsIgnoreCase("SAC")) {
            System.out.println("SAC");
            Query = "Select " + SelectColumn + " from SACRateMaster where SACCode = '" + hsnsaccodevalue + "'";
            System.out.println("Query SAC: " + Query);
        }

        result = formObject.getDataFromDataSource(Query);
        System.out.println("Result size :" + result.size());
        if (result.size() > 0) {
            if ((null == result.get(0).get(0)
                    || "NULL".equalsIgnoreCase(result.get(0).get(0)))) {
                ReverseChargeRate = "0";
//                if (accountype.equalsIgnoreCase("Customer")) {
//                    Query = "select * from CustomerMaster where code = '" + accountcode + "'";
//                } else if (accountype.equalsIgnoreCase("Vendor")) {
//                    Query = "select * from VendorMaster where VendorCode = '" + accountcode + "'";
//                }
//                result = formObject.getDataFromDataSource(Query);
//                System.out.println("Vendor Query :" + Query);
//                if (result.size() > 0) {
//                    ReverseChargeRate = "0";
//                } else {
//                    ReverseChargeRate = "100";
//                }
            } else {
                ReverseChargeRate = result.get(0).get(0);
            }
        }
        System.out.println("ReverseChargeRate :" + ReverseChargeRate);
        return ReverseChargeRate;
    }

    String getTaxDocumentXml(String TaxDocumentXML, String LineNumber, String ItemNumber, String GSTIN, String HSNSACType,
            String HSNSACCode, String HSNSACDesc, String TaxComponent, String TaxRate, String TaxAmount, String AdjustmentTaxAmount,
            String NonBusinessUsagePer, String ReverseChargePer, String ReverseChargeAmount,
            String NonGst, String Exempt) {
        TaxDocumentXML = (new StringBuilder()).append(TaxDocumentXML).
                append("<ListItem><SubItem>").append(LineNumber). //line number
                append("</SubItem><SubItem>").append(ItemNumber). //item number
                append("</SubItem><SubItem>").append(GSTIN). //gstingdiuid
                append("</SubItem><SubItem>").append(HSNSACType). //hsnsac type
                append("</SubItem><SubItem>").append(HSNSACCode). //hsnsac code
                append("</SubItem><SubItem>").append(HSNSACDesc). //hsnsac description
                append("</SubItem><SubItem>").append(TaxComponent). //tax component
                append("</SubItem><SubItem>").append(TaxRate). //rate
                append("</SubItem><SubItem>").append(TaxAmount). //tax amount
                append("</SubItem><SubItem>").append(AdjustmentTaxAmount). //adjustment tax amount
                append("</SubItem><SubItem>").append(NonBusinessUsagePer). //non business usage %
                append("</SubItem><SubItem>").append(ReverseChargePer). //reverse charge %
                append("</SubItem><SubItem>").append(ReverseChargeAmount). //reverse charge amount
                append("</SubItem><SubItem>").append(""). //cstvat %
                append("</SubItem><SubItem>").append(""). //cstvat amount
                append("</SubItem><SubItem>").append(NonGst). //Non-Gst
                append("</SubItem><SubItem>").append(Exempt). //exempt
                append("</SubItem></ListItem>").toString();

        return TaxDocumentXML;
    }

}
