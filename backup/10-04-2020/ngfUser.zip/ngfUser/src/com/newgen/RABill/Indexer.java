/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.RABill;

import com.newgen.Webservice.CallAccessTokenService;
import com.newgen.Webservice.CallGetStockDetailsService;
import com.newgen.Webservice.CallPurchaseOrderService;
import com.newgen.common.Calculations;
import com.newgen.common.General;
import com.newgen.common.PicklistListenerHandler;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.component.ListView;
import com.newgen.omniforms.component.PickList;
import com.newgen.omniforms.context.FormContext;
import com.newgen.omniforms.event.ComponentEvent;
import com.newgen.omniforms.event.FormEvent;
import com.newgen.omniforms.listener.FormListener;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author Admin
 */
public class Indexer implements FormListener {

    FormReference formObject = null;
    FormConfig formConfig = null;
    List<List<String>> result;
    String activityName = null, engineName = null, sessionId = null, folderId = null, serverUrl = null,
            processInstanceId = null, workItemId = null, userName = null, processDefId = null, Query = null;

    PickList objPicklist;
    General objGeneral = null;
    Calculations objCalculations = null;
    PicklistListenerHandler objPicklistListenerHandler = null;
    CallGetStockDetailsService objCallGetStockDetails = null;

    @Override
    public void formLoaded(FormEvent fe) {
        formObject = FormContext.getCurrentInstance().getFormReference();
        formConfig = FormContext.getCurrentInstance().getFormConfig();

        try {
            engineName = formConfig.getConfigElement("EngineName");
            sessionId = formConfig.getConfigElement("DMSSessionId");
            folderId = formConfig.getConfigElement("FolderId");
            serverUrl = formConfig.getConfigElement("ServletPath");
            activityName = formObject.getWFActivityName();
            processInstanceId = formConfig.getConfigElement("ProcessInstanceId");
            workItemId = formConfig.getConfigElement("WorkitemId");
            userName = formConfig.getConfigElement("UserName");
            processDefId = formConfig.getConfigElement("ProcessDefId");

            System.out.println("ProcessInstanceId===== " + processInstanceId);
            System.out.println("Activityname=====" + activityName);
            System.out.println("CabinetName====" + engineName);
            System.out.println("sessionId====" + sessionId);
            System.out.println("Username====" + userName);
            System.out.println("workItemId====" + workItemId);
        } catch (Exception e) {
            System.out.println("Exception in FieldValueBagSet::::" + e.getMessage());
        }
    }

    @Override
    public void formPopulated(FormEvent fe) {
        formObject = FormContext.getCurrentInstance().getFormReference();
        System.out.println("inside form populated of indexer");
        formObject.clear("filestatus");
        System.out.println("after clear" + formObject.getNGValue("previousactivity"));

        Query = "select StateName from StateMaster order by StateCode asc";
        System.out.println("Query is " + Query);
        result = formObject.getDataFromDataSource(Query);
        System.out.println("resut is " + result);
        for (int i = 0; i < result.size(); i++) {
            formObject.addComboItem("state", result.get(i).get(0), result.get(i).get(0));
        }
        //for Location
        Query = "select WMSLocationId from WarehouseLocationMaster where WarehouseCode='" + formObject.getNGValue("warehouse") + "'";
        System.out.println("query" + Query);
        result = formObject.getDataFromDataSource(Query);
        System.out.println("result" + result);
        for (int i = 0; i < result.size(); i++) {
            formObject.addComboItem("location", result.get(i).get(0).toString(), result.get(i).get(0).toString());
        }

        String[] arr2 = processInstanceId.split("-");
        String st = arr2[1];
        String str = "";
        for (int i = 0; i < st.length(); i++) {
            if (st.charAt(i) == '0') {

            } else {
                str = str + st.charAt(i);
            }
        }
        System.out.println("var " + str);
        formObject.setNGValue("jointmeasurementcode", str);

        if (!formObject.getNGValue("previousactivity").equalsIgnoreCase("Approver")
                && !formObject.getNGValue("previousactivity").equalsIgnoreCase("Accounts")) {
            System.out.println("inside if ");
            formObject.addComboItem("filestatus", "Initiate", "Initiate");
            formObject.addComboItem("filestatus", "Discard", "Discard");
            formObject.addComboItem("filestatus", "Exception", "Exception");
        } else {
            System.out.println("inside else");
            formObject.addComboItem("filestatus", "Hold", "Hold");
            formObject.addComboItem("filestatus", "Query Cleared", "Query Cleared");
            formObject.addComboItem("filestatus", "Discard", "Discard");
            formObject.addComboItem("filestatus", "Exception", "Exception");
        }
    }

    @Override
    public void saveFormStarted(FormEvent fe) throws ValidatorException {
        formObject = FormContext.getCurrentInstance().getFormReference();
    }

    @Override
    public void saveFormCompleted(FormEvent fe) throws ValidatorException {
        formObject = FormContext.getCurrentInstance().getFormReference();
    }

    @Override
    public void submitFormStarted(FormEvent fe) throws ValidatorException {
        formObject = FormContext.getCurrentInstance().getFormReference();
        objGeneral = new General();
        String levelflag_ = formObject.getNGValue("levelflag");
        int levelflag = Integer.parseInt(levelflag_) + 1;
        String state = formObject.getNGValue("state");
        String purchaseorder = formObject.getNGValue("purchaseorder");

        Query = "select count(*) from ext_rabill ext, WFINSTRUMENTTABLE wf "
                + "where ext.processid = wf.ProcessInstanceID "
                + "and wf.ActivityName not in ('Discard' , 'End') "
                + "and wf.ProcessInstanceID <> '" + processInstanceId + "'"
                + "and ext.purchaseorder = '" + purchaseorder + "'";
        System.out.println("Query is " + Query);
        result = formObject.getDataFromDataSource(Query);
        if (result.get(0).get(0).equalsIgnoreCase("0")) {
            if (formObject.getNGValue("filestatus").equalsIgnoreCase("Exception")) {
                objGeneral.setException(userName, "Combo1", "Text69");
            } else if (formObject.getNGValue("filestatus").equalsIgnoreCase("Initiate")) {
                Query = "select TOP 1 ApproverCode from RABillApproverMaster where Head = 'RABill' and ApproverLevel ='" + levelflag + "'and State ='" + state + "'";
                System.out.println("Query:" + Query);
                result = formObject.getDataFromDataSource(Query);
                if (result.size() > 0) {
                    formObject.setNGValue("nextactivity", "Approver");
                    formObject.setNGValue("assignto", result.get(0).get(0));
                    formObject.setNGValue("levelflag", levelflag);
                } else {
                    Query = "select ApproverLevel, ApproverCode from RABillApproverMaster where "
                            + "head = 'RABill' and "
                            + "state = '" + (formObject.getNGValue("state")) + "'"
                            + " and approverlevel in ('Maker','Checker')";
                    System.out.println("Query form Maker n checker is" + Query);
                    result = formObject.getDataFromDataSource(Query);
                    if (result.size() > 0) {
                        if (result.get(0).get(0).equalsIgnoreCase("Maker")) {
                            formObject.setNGValue("levelflag", "Maker");
                        } else if (result.get(0).get(0).equalsIgnoreCase("Checker")) {
                            formObject.setNGValue("levelflag", "Checker");
                        }
                        formObject.setNGValue("assignto", result.get(0).get(1));
                        formObject.setNGValue("nextactivity", "Accounts");
                    } else {
                        formObject.setNGValue("nextactivity", "SchedulerAccount");
                    }
                }
            }
            formObject.setNGValue("previousactivity", activityName);
            System.out.println("before history");
            objGeneral.maintainHistory(userName, activityName, formObject.getNGValue("filestatus"), "", formObject.getNGValue("Text69"), "q_transactionhistory");
        } else {
            throw new ValidatorException(new FacesMessage("RABill with same purchase order number is already in process"));
        }

    }

    @Override
    public void submitFormCompleted(FormEvent fe) throws ValidatorException {
        formObject = FormContext.getCurrentInstance().getFormReference();
    }

    @Override
    public void eventDispatched(ComponentEvent pEvent) throws ValidatorException {
        System.out.println("Value Change Event :" + pEvent);
        System.out.println("pEvent.getType() :" + pEvent.getType());
        System.out.println("pEvent.getType().name() :" + pEvent.getType().name());
        formObject = FormContext.getCurrentInstance().getFormReference();
        objPicklistListenerHandler = new PicklistListenerHandler();
        objCalculations = new Calculations();
        objGeneral = new General();
        switch (pEvent.getType().name()) {
            case "VALUE_CHANGED":
                switch (pEvent.getSource().getName()) {
                    case "qpo_quantity":
                        float remainingQty = getRemainingQty();
                        formObject.setNGValue("qpo_remainingqty", remainingQty);
//                        BigDecimal netamount = new BigDecimal(remainingQty).multiply(new BigDecimal(formObject.getNGValue("qpo_unitprice"))).setScale(2, BigDecimal.ROUND_FLOOR);
//                        formObject.setNGValue("qpo_netamount", netamount);
                        break;

                    case "qpo_currentquantity":
                        boolean errorflag = false;
                        String errormsg = "";
                        float qpo_currentquantity = Float.parseFloat(formObject.getNGValue("qpo_currentquantity"));

                        if (qpo_currentquantity == 0) {
                            errorflag = true;
                            errormsg = "Quantity can't be zero";
                        }

                        if (qpo_currentquantity > Float.parseFloat(formObject.getNGValue("qpo_remainingqty"))) {
                            errorflag = true;
                            errormsg = "Entered quantity exceed the remaining quantity";
                        }
                        if (errorflag) {
                            formObject.setNGValue("qpo_currentquantity", formObject.getNGValue("qpo_remainingqty"));
                            BigDecimal remnetamount = new BigDecimal(qpo_currentquantity).multiply(new BigDecimal(formObject.getNGValue("qpo_unitprice"))).setScale(2, BigDecimal.ROUND_FLOOR);
                            formObject.setNGValue("qpo_netamount", remnetamount);
                            formObject.setNGValue("qpo_assessableamount", remnetamount);
                            throw new ValidatorException(new FacesMessage(errormsg, ""));
                        } else {
                            BigDecimal remnetamount = new BigDecimal(qpo_currentquantity).multiply(new BigDecimal(formObject.getNGValue("qpo_unitprice"))).setScale(2, BigDecimal.ROUND_FLOOR);
                            formObject.setNGValue("qpo_netamount", remnetamount);
                            formObject.setNGValue("qpo_assessableamount", remnetamount);
                        }
                        break;

                    case "location":
                        String location = formObject.getNGValue("location");
                        System.out.println("location " + location);
                        if (location.equalsIgnoreCase("--Select--")) {
                            formObject.setNGValue("abs_location", "");
                        } else {
                            formObject.setNGValue("abs_location", location);
                        }
                        break;

                    case "filestatus":
                        System.out.println("inside value change of file status");
                        String filestatus = formObject.getNGValue("filestatus");
                        if (filestatus.equalsIgnoreCase("Exception")) {
                            System.out.println("inside if");
                            formObject.setVisible("Label58", true);
                            formObject.setVisible("Combo1", true);
                            //to add the values in combo box
                            formObject.addComboItem("Combo1", "PO number not mentioned on invoice", "PO number not mentioned on invoice");
                            formObject.addComboItem("Combo1", "Incorrect PO number on invoice", "Incorrect PO number on invoice");
                            formObject.addComboItem("Combo1", "Invoice Number not mentioned on invoice", "Invoice Number not mentioned on invoice");
                            formObject.addComboItem("Combo1", "Incorrect invoice number on invoice", "Incorrect invoice number on invoice");
                            formObject.addComboItem("Combo1", "Incorrect details of Wonder Cement on invoice", "Incorrect details of Wonder Cement on invoice");
                            formObject.addComboItem("Combo1", "Mismatch of vendor name in invoice and PO", "Mismatch of vendor name in invoice and PO");

                        }
                        break;

                    case "ij_projectcode":
                        if (!formObject.getNGValue("ij_projectcode").equalsIgnoreCase("")) {
                            Query = "select remainingqty from cmplx_raabstractsheet "
                                    + "where pinstanceid = '" + processInstanceId + "'";
                            result = formObject.getDataFromDataSource(Query);
                            formObject.setNGValue("ij_quantity", result.get(0).get(0));
                            formObject.setNGValue("ij_location", formObject.getNGValue("location"));
                            formObject.setNGValue("ij_sitecode", formObject.getNGValue("site"));
                            formObject.setNGValue("ij_warehousecode", formObject.getNGValue("warehouse"));
                            Query = "select concat(sitecode,'-',sitename) from SiteMaster "
                                    + "where SiteCode = '" + formObject.getNGValue("ij_sitecode") + "'";
                            result = formObject.getDataFromDataSource(Query);
                            formObject.setNGValue("ij_site", result.get(0).get(0));

                            Query = "select concat(cast(warehousecode as varchar),'-',warehousename) "
                                    + "from WarehouseMaster where WarehouseCode = '" + formObject.getNGValue("ij_warehousecode") + "'";
                            result = formObject.getDataFromDataSource(Query);
                            formObject.setNGValue("ij_warehouse", result.get(0).get(0));
                            //

//                            Query = "select ProjCategoryDesc from ProjectCategoryMaster "
//                                    + "where ProjCategoryCode='" + formObject.getNGValue("ij_projectcode") + "'";
//                            result = formObject.getDataFromDataSource(Query);
//                            if (result.isEmpty()) {
//                                throw new ValidatorException(new FacesMessage("Project category not defined in master", ""));
//                            } else {
//                                formObject.setNGValue("ij_projectcategory", result.get(0).get(0));
//                            }
                        }
                        break;
                }
                break;

            case "MOUSE_CLICKED":
                switch (pEvent.getSource().getName()) {
                    case "Btn_fetchPO":
                        System.out.println("Inside button click fetch PO");
                        String AccessToken = new CallAccessTokenService().getAccessToken();
                        new CallPurchaseOrderService().GetSetPurchaseOrder(AccessToken, "RABill", formObject.getNGValue("purchaseorder"));

                        Query = "select WMSLocationId from WarehouseLocationMaster where WarehouseCode='" + formObject.getNGValue("warehouse") + "'";
                        result = formObject.getDataFromDataSource(Query);
                        System.out.println("result");
                        formObject.clear("location");
                        for (int i = 0; i < result.size(); i++) {
                            formObject.addComboItem("location", result.get(i).get(0).toString(), result.get(i).get(0).toString());
                        }
                        break;

                    case "Btn_Add_AbstractSheet":
                        String alertmsg = "";
                        boolean rowexist = false;
                        ListView ListViewq_raabstractsheet = (ListView) formObject.getComponent("q_raabstractsheet");
                        int RowCountq_raabstractsheet = ListViewq_raabstractsheet.getRowCount();
                        for (int j = 0; j < RowCountq_raabstractsheet; j++) {
//                            if (formObject.getNGValue("qpo_linenumber").equalsIgnoreCase(formObject.getNGValue("q_raabstractsheet", j, 0))) {
//                                rowexist = true;
//                                alertmsg = "Same Line No already added";
//                                break;
//                            }
                            if ((formObject.getNGValue("qpo_itemnumber").equalsIgnoreCase(formObject.getNGValue("q_raabstractsheet", j, 1)))
                                    && (formObject.getNGValue("qpo_structurecode").equalsIgnoreCase(formObject.getNGValue("q_raabstractsheet", j, 2)))) {
                                rowexist = true;
                                alertmsg = "Same Line No already added";
                                break;
                            }
                        }

                        if (rowexist) {
                            throw new ValidatorException(new FacesMessage(alertmsg, ""));
                        } else {
                            BigDecimal netamount = new BigDecimal(formObject.getNGValue("qpo_netamount"));
                            float unitprice = Float.parseFloat(formObject.getNGValue("qpo_unitprice"));
                            float receivedqty = Float.parseFloat(formObject.getNGValue("qpo_recievedqty"));
                            float deliveredValue = unitprice * receivedqty;
                            String AbstractsheetXML = "";
                            AbstractsheetXML = (new StringBuilder()).append(AbstractsheetXML).
                                    append("<ListItem><SubItem>").append(formObject.getNGValue("qpo_linenumber")). //Line Number
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_itemnumber")). //Item Number
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_structurecode")). //Structure Code
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_structurename")). //Structre Name
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_linenumber")). //Item Selection
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_unitprice")). //Unit Price
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_quantity")). //Total Quantity
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_recievedqty")). //Delivered Quantity
                                    append("</SubItem><SubItem>").append(deliveredValue). //Delivered Amount
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_remainingqty")). //Remaining Quantity
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_currentquantity")). //Current Quantity
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_netamount")). //Net Amount
                                    append("</SubItem><SubItem>").append(formObject.getNGValue("qpo_assessableamount")). //Assessable Amount                                   
                                    append("</SubItem></ListItem>").toString();

                            System.out.println("Abstract Sheet XML " + AbstractsheetXML);
                            formObject.NGAddListItem("q_raabstractsheet", AbstractsheetXML);
                            formObject.setNGValue("qpo_structurename", "");
                            formObject.setNGValue("qpo_structurecode", "");
                            formObject.setNGValue("qpo_netamount", "");
                            formObject.setNGValue("qpo_currentquantity", "");
                            formObject.RaiseEvent("WFSave");

                            //by farman
                            BigDecimal bookedamount = BigDecimal.ZERO;
                            Query = "select SUM(cast(netamount as numeric(38,2))) from cmplx_raabstractsheet "
                                    + "where pinstanceid = '" + processInstanceId + "'";
                            System.out.println("Query :" + Query);
                            result = formObject.getDataFromDataSource(Query);
                            System.out.println("Result -> " + result.get(0).get(0));
                            if (null != result.get(0).get(0)) {
                                bookedamount = new BigDecimal(result.get(0).get(0)).add(netamount);
                            } else {
                                bookedamount = netamount;
                            }
                            System.out.println("bookedamount : " + bookedamount);
                            formObject.setNGValue("bookedamount", bookedamount);
                        }

                        break;

                    case "Btn_Delete_AbstractSheet":
                        ListView ListViewq_raabstractsheet3 = (ListView) formObject.getComponent("q_raabstractsheet");
                        int RowCountq_raabstractsheet3 = ListViewq_raabstractsheet3.getRowCount();
                        formObject.clear("ij_projectcode");
                        for (int j = 0; j < RowCountq_raabstractsheet3; j++) {
                            formObject.addComboItem("ij_projectcode", formObject.getNGValue("q_raabstractsheet", j, 2), formObject.getNGValue("q_raabstractsheet", j, 2));
                        }

                        BigDecimal currentbookedamount = new BigDecimal(formObject.getNGValue("bookedamount"));
                        BigDecimal linenetamount = new BigDecimal(formObject.getNGValue("qab_netamount"));
                        BigDecimal bookedamount = currentbookedamount.subtract(linenetamount);
                        formObject.setNGValue("bookedamount", bookedamount);
                        formObject.ExecuteExternalCommand("NGDeleteRow", "q_raabstractsheet");
                        formObject.RaiseEvent("WFSave");
                        break;

                    case "Btn_Add_Itemjournal":
                        System.out.println("Inside Btn_Add_Itemjournal");
                        formObject.ExecuteExternalCommand("NGAddRow", "q_raitemjournal");
                        break;

                    case "Btn_Delete_Itemjournal":
                        formObject.ExecuteExternalCommand("NGDeleteRow", "q_raitemjournal");
                        break;

                    case "Btn_Modify_Itemjournal":
                        formObject.ExecuteExternalCommand("NGModifyRow", "q_raitemjournal");
                        break;

                    case "Btn_Validate_Itemjournal":
                        System.out.println("inside Btn_Validate_Itemjournal");
                        String AccessToken_1 = new CallAccessTokenService().getAccessToken();
                        new CallGetStockDetailsService().GetSetStockDetails(AccessToken_1, processInstanceId);
                        System.out.println("after");
                        formObject.ExecuteExternalCommand("NGModifyRow", "q_raitemjournal");
                        break;

                    case "Pick_structurename":
                        Query = "select ProjectCode,ProjectDesc from ProjectMaster";
                        objPicklistListenerHandler.openPickList("qpo_structurename", "ProjectCode,ProjectDesc", "Structure Master", 70, 70, Query);
                        break;

                    case "Pick_configuration":
                        Query = "select ItemCode,CofigurationCode from ItemConfigurationMaster";
                        objPicklistListenerHandler.openPickList("ij_configuration", "Item Code,Configuration Code", "Configuration Master", 70, 70, Query);
                        break;

                    case "Pick_site":
                        Query = "select SiteCode,SiteName from SiteMaster order by SiteCode asc";
                        objPicklistListenerHandler.openPickList("ij_site", "Site Code,Site Name", "Site Master", 70, 70, Query);
                        break;

                    case "Pick_itemno":
                        Query = "select ItemCode,ItemShortDesc from RABillItemMaster order by ItemCode asc";
                        objPicklistListenerHandler.openPickList("ij_itemdesc", "Item Code,Item Description", "Item Number Master", 70, 70, Query);
                        break;

                    case "Pick_projectcategory":
                        Query = "select ProjCategoryCode,ProjCategoryDesc from ProjectCategoryMaster order by ProjCategoryDesc asc";
                        objPicklistListenerHandler.openPickList("ij_projectcategory", "Code,Category", "Project Category Master", 70, 70, Query);
                        break;
                }
                break;

            case "TAB_CLICKED":
                switch (pEvent.getSource().getName()) {
                    case "Tab1":
                        switch (formObject.getSelectedSheet("Tab1")) {
                            case 2: {
                                addProjectCode();
                            }
                            break;
                        }
                        break;
                }
                break;
        }
    }

    @Override
    public void continueExecution(String string, HashMap<String, String> hm
    ) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void initialize() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String encrypt(String string
    ) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String decrypt(String string
    ) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    float getRemainingQty() {
        formObject = FormContext.getCurrentInstance().getFormReference();
        ListView ListViewq_polinedetails = (ListView) formObject.getComponent("q_polinedetails");
        int selectedRowIndex = ListViewq_polinedetails.getSelectedRowIndex();
        float totalQty = Float.parseFloat(formObject.getNGValue("q_polinedetails", selectedRowIndex, 3));
        float receivedQty = Float.parseFloat(formObject.getNGValue("q_polinedetails", selectedRowIndex, 72));
        formObject.setNGValue("qpo_unitprice", formObject.getNGValue("q_polinedetails", selectedRowIndex, 5));
        return totalQty - receivedQty;
    }

    void addProjectCode() {
        formObject = FormContext.getCurrentInstance().getFormReference();
        formObject.clear("ij_projectcode");
        ListView ListViewq_raabstractsheet2 = (ListView) formObject.getComponent("q_raabstractsheet");
        int RowCountq_raabstractsheet2 = ListViewq_raabstractsheet2.getRowCount();
        for (int j = 0; j < RowCountq_raabstractsheet2; j++) {
            formObject.addComboItem("ij_projectcode", formObject.getNGValue("q_raabstractsheet", j, 2), formObject.getNGValue("q_raabstractsheet", j, 2));
        }
    }
}
