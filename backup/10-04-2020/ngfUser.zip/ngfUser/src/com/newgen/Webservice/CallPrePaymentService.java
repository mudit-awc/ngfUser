/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.Webservice;

import com.newgen.common.General;
import com.newgen.common.ReadProperty;
import com.newgen.omniforms.FormConfig;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author V_AWC
 */
public class CallPrePaymentService {

    FormReference formObject;
    FormConfig formConfig = null;
    General objGeneral = null;
    ReadProperty objReadProperty = null;
    ServiceConnection objServiceConnection = null;
    String webserviceStatus;
    private List<List<String>> result;
    private String outputJSON;
    private String Query;

    public void GetSetPrePaymentLines(String AccessToken, String PONumber, String POType) {
        formObject = FormContext.getCurrentInstance().getFormReference();
        formConfig = FormContext.getCurrentInstance().getFormConfig();
        objServiceConnection = new ServiceConnection();
        objReadProperty = new ReadProperty();
        JSONObject request_json = new JSONObject();
        try {
            if (POType.equalsIgnoreCase("Supply")) {
                request_json.put("_PONumber", PONumber);
                outputJSON = objServiceConnection.callBearerAuthWebService(
                        AccessToken,
                        objReadProperty.getValue("getPrePaymentLines"),
                        request_json.toString().trim());
            } else {
                Query = "select purchaseorderno from cmplx_multiplepo where pinstanceid = '" + formConfig.getConfigElement("ProcessInstanceId") + "'";
                result = formObject.getDataFromDataSource(Query);
                if (result.size() > 0) {
                    for (int i = 0; i < result.size(); i++) {
                        request_json.put("_PONumber", result.get(i).get(0));
                        outputJSON = objServiceConnection.callBearerAuthWebService(
                                AccessToken,
                                objReadProperty.getValue("getPrePaymentLines"),
                                request_json.toString().trim());
                    }
                }
            }
            System.out.println("outputJSON : " + outputJSON);
            webserviceStatus = parsePrePaymentOutputJSON(outputJSON);
        } catch (JSONException ex) {
            Logger.getLogger(CallPurchaseOrderService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("IsStatus return :call purchase order : " + webserviceStatus);
        if (!webserviceStatus.equalsIgnoreCase("true")) {
            throw new ValidatorException(new FacesMessage("Error : " + webserviceStatus, ""));
        }
    }

    public String parsePrePaymentOutputJSON(String content) throws JSONException {
        formObject = FormContext.getCurrentInstance().getFormReference();
        String PrePaymentLineXML = "";
        JSONObject objJSONObject = new JSONObject(content);
        //Check webservice IsSuccess status
        String IsSuccess = objJSONObject.optString("isSuccess");
        String ErrorMessage = objJSONObject.optString("errorMessage");
        System.out.println("IsSuccess : " + IsSuccess);
        System.out.println("ErrorMessage : " + ErrorMessage);
        if (IsSuccess.equalsIgnoreCase("true")) {
            JSONArray objJSONArray_invoiceLineList = objJSONObject.getJSONArray("invoiceLineList");
            for (int i = 0; i < objJSONArray_invoiceLineList.length(); i++) {
                PrePaymentLineXML = (new StringBuilder()).append(PrePaymentLineXML).
                        append("<ListItem><SubItem>").append(objJSONArray_invoiceLineList.getJSONObject(i).optString("invoiceID")).
                        append("</SubItem><SubItem>").append(objJSONArray_invoiceLineList.getJSONObject(i).optString("totalAmount")).
                        append("</SubItem><SubItem>").append("0").
                        append("</SubItem><SubItem>").append(objJSONArray_invoiceLineList.getJSONObject(i).optString("remainAmount")).
                        append("</SubItem></ListItem>").toString();
            }
            formObject.clear("q_prepayment");
            try {
                formObject.NGAddListItem("q_prepayment", PrePaymentLineXML);
            } catch (Exception e) {
                System.out.println("Exception in adding line item :" + e);
            }
            return IsSuccess;
        } else {
            return ErrorMessage;
        }
    }
}
