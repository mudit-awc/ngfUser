/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.newgen.Webservice;

import com.newgen.SupplyPoInvoices.Initiator;
import com.newgen.common.General;
import com.newgen.common.ReadProperty;
import com.newgen.omniforms.FormReference;
import com.newgen.omniforms.context.FormContext;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author V_AWC
 */
public class CallGetStockDetailsService {

    FormReference formObject;
    General objGeneral = null;
    ReadProperty objReadProperty = null;
    String webserviceStatus;

    public void GetSetStockDetails(String AccessToken, String processInstanceId) {
        formObject = FormContext.getCurrentInstance().getFormReference();
        System.out.println("inside GetSetStockDetails function");
        try {
            objReadProperty = new ReadProperty();
            JSONObject request_json = new JSONObject();
            String Query = "select ab.itemnumber,po.inventorylocation,po.inventorysite,po.inventorywarehouse "
                    + "from cmplx_polinedetails po, cmplx_raabstractsheet ab "
                    + "where po.pinstanceid = ab.pinstanceid "
                    + "and po.linenumber = ab.linenumber "
                    + "and po.itemnumber = ab.itemnumber "
                    + "and ab.pinstanceid = '" + processInstanceId + "'";
            System.out.println("Query : " + Query);
            List<List<String>> result = formObject.getDataFromDataSource(Query);
            System.out.println("result : " + result);
            if (result.size() > 0) {
                for (int i = 0; i < result.size(); i++) {
//                    request_json.put("_itemNumber", result.get(i).get(0));
//                    request_json.put("_inventSiteId", result.get(i).get(1));
//                    request_json.put("_inventLocationId", result.get(i).get(2));
//                    request_json.put("_wmsLocationId", result.get(i).get(3));

                    request_json.put("_itemNumber", "100000001");
                    request_json.put("_inventSiteId", "101");
                    request_json.put("_inventLocationId", "101001");
                    request_json.put("_wmsLocationId", "AAL-001");
                    request_json.put("_inventBatchId", "");
                    request_json.put("_inventSerialId", "");
                    request_json.put("_configurationName", "NA");

                    String outputJSON = callStockDetailsWebService(
                            AccessToken,
                            objReadProperty.getValue("getStockDetailsData"),
                            request_json.toString().trim()
                    );
                    System.out.println("outputJSON Get Stock Details: " + outputJSON);

                    webserviceStatus = parseStockDetailsOutputJSON(outputJSON);
                    //  addToSypplyInvoice();
                    System.out.println("IsStatus return : get stock ::  " + webserviceStatus);
                }
            }
        } catch (JSONException ex) {
            Logger.getLogger(CallGetStockDetailsService.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (!webserviceStatus.equalsIgnoreCase("true")) {
            throw new ValidatorException(new FacesMessage("Error : " + webserviceStatus, ""));
        }
    }

    private String parseStockDetailsOutputJSON(String content) throws JSONException {
        formObject = FormContext.getCurrentInstance().getFormReference();
        System.out.println("inside parse parseStockDetailsOutputJSON OutputJSON @");
        JSONObject objJSONObject = new JSONObject(content);
        //Check webservice IsSuccess status
        String IsSuccess = objJSONObject.optString("isSuccess");
        String ErrorMessage = objJSONObject.optString("errorMessage");
        System.out.println("IsSuccess : " + IsSuccess);
        System.out.println("ErrorMessage :call purchase order :" + ErrorMessage);
        if (IsSuccess.equalsIgnoreCase("true")) {
            System.out.println("inside trueeeeeeeee");

            return IsSuccess;

        } else {
            return ErrorMessage;
        }
    }

    private String callStockDetailsWebService(String AccessToken, String serviceURL, String inputJSON) {
        String outputJSON = "";
        try {
            System.out.println("inside my service getstock details");
            System.out.println("AccessToken : " + AccessToken);
            System.out.println("URL : " + serviceURL);
            System.out.println("inputjson : " + inputJSON);

            URL url = new URL(serviceURL);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + AccessToken);

            OutputStream os = conn.getOutputStream();
            os.write(inputJSON.getBytes());
            os.flush();
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            outputJSON = br.readLine();
            System.out.println("Output JSON.... " + outputJSON);
        } catch (MalformedURLException ex) {
            Logger.getLogger(Initiator.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Initiator.class.getName()).log(Level.SEVERE, null, ex);
        }
        return outputJSON;
    }
//    final static HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() {
//        public boolean verify(String hostname, SSLSession session) {
//            return true;
//        }
//    };
}
